package com.cg.employeemanagement.exception;

public class EmpException extends RuntimeException{
	public EmpException(String str) {
		// TODO Auto-generated constructor stub
		super(str);
	}
}
