package com.cg.employeemanagement.dao;

import java.util.List;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.dto.Leave;


public interface ManagerDao {
	public Employee searchEmployeeById(int empId);
	public List<Employee> searchEmployeeByName(String fName);
	public Employee displayOwnDetials(String useName);
	public List<Employee> displaySubEmployees(String userName);
	public List<Leave> showLeavesApplied(String userName);
	public boolean accept(int leaveId);
	public boolean reject(int leaveId,String reason);
	public boolean changeAccountPassword(String oldPassword, String newPassword,String userName);
}
