package com.cg.employeemanagement.dao;

public interface LoginDao {
	public boolean validate(String userName,String pwd,int userRole);
}
