package com.cg.employeemanagement.dao;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.dto.Leave;
import com.cg.employeemanagement.dto.Login;
import com.cg.employeemanagement.entity.EmployeeStaticDB;
import com.cg.employeemanagement.entity.LeaveResponseStaticDB;
import com.cg.employeemanagement.entity.LeavesStaticDB;
import com.cg.employeemanagement.entity.LoginDatabase;
import com.cg.employeemanagement.entity.ReviewedLeavesStaticDB;




public class ManagerDaoImpl implements ManagerDao {
	
	EmployeeStaticDB esdb = new EmployeeStaticDB();
	LoginDatabase loginDB = new LoginDatabase();
	LeavesStaticDB lsDB = new LeavesStaticDB();
	LeaveResponseStaticDB leaveResStaticDb = new LeaveResponseStaticDB();
	ReviewedLeavesStaticDB reviewedLeavesStaticDb = new ReviewedLeavesStaticDB();
	@Override
	public Employee searchEmployeeById(int empId) {
		// the function should return the employee details based on the employee id
		for(Employee emp : esdb.getEmployeeList())
		{
			if(emp.getUserId()==empId)
			{
				return emp;
			}
		}
		return null;
	}
	
	@Override
	public List<Employee> searchEmployeeByName(String name) {
		List<Employee> empList = new ArrayList<Employee>();
		for(Employee emp : esdb.getEmployeeList())
		{
			if(emp.getUserName().equals(name))
			{
				empList.add(emp);
			}
		}
		return empList;
	}
	
	@Override
	public Employee displayOwnDetials(String userName) {
		int id = loginDB.getId(userName);
		for(Employee emp : esdb.getEmployeeList())
		{
			if(emp.getUserId()==id)
			{
				return emp;
			}
		}
		return null;
	}
	
	@Override
	public List<Employee> displaySubEmployees(String userName) {
		List<Employee> teamList = new ArrayList<Employee>();
		int id = loginDB.getId(userName);
		for(Employee emp : esdb.getEmployeeList())
		{
			if(emp.getManagerId()==id)
			{
				teamList.add(emp);
			}
		}
		return teamList;
	}
	
	@Override
	public List<Leave> showLeavesApplied(String userName) {
		// it should display all the leaves applied by the employees how have the managerId as manager own id.
		int id = loginDB.getId(userName);
		List<Leave> finalList = new ArrayList<>();
		List<Leave> leaveList = lsDB.getLeavesList();
		for(Leave leave : leaveList)
		{
			if(leave.getManagerId()==id)
			{
				finalList.add(leave);
			}
		}
		return leaveList;
	}

	@Override
	public boolean accept(int leaveId) {
		// The function should accept the leave based on leaveid and the number of leaves of that particular employee should be decreased.
		int empId=0;
		long numberOfDaysLeaveApplied=0;
		Leave l;
		int leaveIdNum=0;
		for(Leave leave : lsDB.getLeavesList())
		{
			if(leave.getLeaveId()==leaveId)
			{
				empId=leave.getEmpId();
				l=leave;
				leaveIdNum=leave.getLeaveId();
				numberOfDaysLeaveApplied=ChronoUnit.DAYS.between(leave.getToDate(), leave.getFromDate());
				leave.setLeaveStatus(true);
				reviewedLeavesStaticDb.add(leave);
			}
		}
		for(Employee emp : esdb.getEmployeeList())
		{
			if(emp.getUserId()==empId)
			{
				if(numberOfDaysLeaveApplied<emp.getNoOfLeaves())
				{
					emp.setNoOfLeaves(emp.getNoOfLeaves()-(int)numberOfDaysLeaveApplied);
				}
			}
		}
		lsDB.removeLeave(leaveIdNum);
		return true;
	}

	@Override
	public boolean reject(int leaveId,String reason) {
		//manager can reject a leave by mentioning the reason for it.
		for(Leave leave : lsDB.getLeavesList())
		{
			if(leave.getLeaveId()==leaveId)
			{
				leave.setLeaveStatus(false);
				leave.setReason(reason);
				reviewedLeavesStaticDb.add(leave);
				lsDB.removeLeave(leaveId);
			}
		}
		
		return true;
	}
	@Override
	public boolean changeAccountPassword(String oldPassword, String newPassword,String userName)
	{
		int id = loginDB.getId(userName);
		for(Login login : loginDB.getLoginDetails())
		{
			if(login.getEmpId()==id)
			{
				login.setPassword(newPassword);
				return true;
			}
		}
		return false;
	}

	

	

	

	
	
}
