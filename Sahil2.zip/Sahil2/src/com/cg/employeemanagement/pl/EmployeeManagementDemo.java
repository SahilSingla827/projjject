package com.cg.employeemanagement.pl;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.cg.employeemanagement.dao.EmployeeDao;
import com.cg.employeemanagement.dao.EmployeeDaoImpl;
import com.cg.employeemanagement.dao.LoginDao;
import com.cg.employeemanagement.dao.LoginDaoImpl;
import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.dto.Leave;
import com.cg.employeemanagement.exception.EmpException;
import com.cg.employeemanagement.services.AdminService;
import com.cg.employeemanagement.services.AdminServiceImpl;
import com.cg.employeemanagement.services.LoginService;
import com.cg.employeemanagement.services.LoginServiceImpl;
import com.cg.employeemanagement.services.ManagerService;
import com.cg.employeemanagement.services.ManagerServiceImpl;



public class EmployeeManagementDemo {

	public static void main(String[] args) {

		System.out.println("Login types:\n"
				+ "\tEnter 1 for : Admin \n "
				+ "\tEnter 2 for : Manager\n "
				+ "\tEnter 3 for : Employee");
		int loginChoice;
		int choice;
		LoginService loginService =new LoginServiceImpl();
		Scanner scanner=new Scanner(System.in);
		loginChoice=scanner.nextInt();
		String userName;
		String password;
		boolean valid;
		System.out.println("Enter your User Name:");
		userName=scanner.next();
		System.out.println("Enter your password:");
		password=scanner.next();
		valid=loginService.validate(userName, password,loginChoice);
		//System.out.println(valid);
		if(valid && loginChoice==1)
		{
			System.out.println("Admin:\n"
					+ "\t1.Add Employee\n"
					+ "\t2.Delete Employee\n"
					+ "\t3.Modify employee By Id\n"
					+ "\t4.Search employee by Id\n"
					+ "\t5.Search employee by name\n"
					+ "\t6.display all the employees");
			
			choice=scanner.nextInt();
			
			AdminService adminService=new AdminServiceImpl();
			
			switch(choice)
			{
				case 1:
					Employee emp;
					System.out.println("Enter Employee Name:");
					String empName=scanner.nextLine();
					scanner.nextLine();
					System.out.println("Enter Employee Salary");
					float empSalary=scanner.nextFloat();
					System.out.println("Enter Employee Department Id");
					int empDeptId=scanner.nextInt();
					System.out.println("Enter employee date of birth in the format yyyy mm dd");
					int year=scanner.nextInt();
					int month=scanner.nextInt();
					int dayOfMonth=scanner.nextInt();
					LocalDate empDOB=LocalDate.of(year, month, dayOfMonth);
					System.out.println("Enter Employee Contact Number");
					Long empContactNumber=scanner.nextLong();
					System.out.println("Enter Employee Manager Id");
					int empManagerId=scanner.nextInt();
					emp=new Employee(empName,empSalary,empDeptId,empDOB,empContactNumber,empManagerId,22);
					boolean status=adminService.addEmployee(emp);
					if(status)
					{
						System.out.println("Employee is added successfully");
					}
					else
					{
						throw new EmpException("error in adding the new employee to the database");
					}
					break;
					
				case 2:
					System.out.println("Enter Employee Id for deletion");
					int empDeleteId=scanner.nextInt();
					boolean deletionStatus=adminService.deleteEmployeeById(empDeleteId);
					if(deletionStatus)
					{
						System.out.println("Employee is deleted Sucessfully");
					}
					else
					{
						throw new EmpException("error in deleting the employee from database");
					}
					break;
				case 3:
					//Im writing code for only name modification as of now
					System.out.println("Enter Employee Id for Modification");
					int empToBeModifiedId=scanner.nextInt();
					System.out.println("\nEnter 1: to update name\n"
							+"Enter 2: to update Salary\n"
							+"Enter 3: to update Department id\n"
							+"Enter 4: to update Date of Birth\n"
							+"Enter 5: to update Contact Number\n"
							+"Enter 6: to update Manager Id\n");
					int modifyChoice=scanner.nextInt();
					boolean bool;
					switch(modifyChoice)
					{
					case 1:
						System.out.println("Enter the new Name");
						String newName=scanner.nextLine();
						bool = adminService.modifyEmployeeName(empToBeModifiedId, newName);
						break;
					case 2:
						System.out.println("Enter the new Salary");
						float newSal=scanner.nextFloat();
						bool = adminService.modifyEmployeeSalary(empToBeModifiedId, newSal);
						break;
					case 3:
						System.out.println("Enter the new Department Id");
						int newdeptId=scanner.nextInt();
						bool = adminService.modifyEmployeeDepartmentId(empToBeModifiedId, newdeptId);
						break;
					case 4:
						System.out.println("Enter the correct Date Of Birth");
						int correctYear=scanner.nextInt();
						int correctMonth=scanner.nextInt();
						int correctDayOfMonth=scanner.nextInt();
						LocalDate newDOB=LocalDate.of(correctYear, correctMonth, correctDayOfMonth);
						bool = adminService.modifyEmployeeDOB(empToBeModifiedId, newDOB);
						break;
					case 5:
						System.out.println("Enter the new Contact Number");
						Long newContactNumber=scanner.nextLong();
						bool = adminService.modifyEmployeeContactNumber(empToBeModifiedId, newContactNumber);
						break;
					case 6:
						System.out.println("Enter the new Manager's Id");
						int newManagerId=scanner.nextInt();
						bool = adminService.modifyEmployeeManagerId(empToBeModifiedId, newManagerId);
						break;
					}
					break;
					
				case 4:
					System.out.println("Enter Employee Id for searching");
					int empIdToBESearched=scanner.nextInt();
					Employee searchEmployee=adminService.searchEmployeeById(empIdToBESearched);
					System.out.println("The employee details are: "+searchEmployee);
					break;
					
				case 5:
					System.out.println("Enter Employee name for searching");
					String empSearchByName=scanner.next();
					List<Employee> employeeList=adminService.searchEmployessByName(empSearchByName);
					for(Employee resultEmp:employeeList)
					{
						System.out.println(resultEmp);
					}
					break;
				case 6:
					List<Employee> empTotalList=adminService.displayEmployees();
					for(Employee totalEmp:empTotalList)
					{
						System.out.println(totalEmp);
					}
					break;
				default:
						System.out.println("Exit");
			}
		}
		else if(valid && loginChoice==2){
			do
			{
				System.out.println("Manager\n"
						+ "\t1.Search an employee by Id\n"
						+ "\t2.Search employee by name\n"
						+ "\t3.Display self details\n"
						+ "\t4.Display subordinates details\n"
						+ "\t5.Show leaves applied by subordinates\n"
						+ "\t6.Accept leave\n"
						+ "\t7.Reject leave"
						+ "\t8. To change Account Password");
				
				choice=scanner.nextInt();
				
				ManagerService managerService=new ManagerServiceImpl();
				switch(choice)
				{
					case 1:
						System.out.println("Enter employee id to be searched");
						int empSearchId=scanner.nextInt();
						Employee searchedEmp=managerService.searchEmployeeById(empSearchId);
						System.out.println("The employee details are: \n");
						System.out.println("\tEmployee Id : "+searchedEmp.getUserId()
								+"\n\tName : "+searchedEmp.getUserName()
								+"\n\tSalary : "+searchedEmp.getSalary()
								+"\n\tDepartment Id : "+searchedEmp.getDepartmentId()
								+"\n\tDate of Birth : "+searchedEmp.getDateOfBirth()
								+"\n\tContact Number : "+searchedEmp.getContactNumber()
								+"\n\tManager Id : "+searchedEmp.getManagerId()
								+"\n\tNumber of leaves left : "+searchedEmp.getNoOfLeaves());
						break;
						
					case 2:
						System.out.println("Enter Employee name to be searched");
						String empName=scanner.next();
						List<Employee> empTotalList=managerService.searchEmployeeByName(empName);
						for(Employee emp:empTotalList)
						{
							System.out.println("\tEmployee Id : "+emp.getUserId()
							+"\n\tName : "+emp.getUserName()
							+"\n\tSalary : "+emp.getSalary()
							+"\n\tDepartment Id : "+emp.getDepartmentId()
							+"\n\tDate of Birth : "+emp.getDateOfBirth()
							+"\n\tContact Number : "+emp.getContactNumber()
							+"\n\tManager Id : "+emp.getManagerId()
							+"\n\tNumber of leaves left : "+emp.getNoOfLeaves());
						}
						break;
						
					case 3:
						System.out.println(userName);
						Employee empOwnDetails = managerService.displayOwnDetails(userName);
						System.out.println(empOwnDetails);
						System.out.println("\tEmployee Id : "+empOwnDetails.getUserId()
						+"\n\tName : "+empOwnDetails.getUserName()
						+"\n\tSalary : "+empOwnDetails.getSalary()
						+"\n\tDepartment Id : "+empOwnDetails.getDepartmentId()
						+"\n\tDate of Birth : "+empOwnDetails.getDateOfBirth()
						+"\n\tContact Number : "+empOwnDetails.getContactNumber()
						+"\n\tManager Id : "+empOwnDetails.getManagerId()
						+"\n\tNumber of leaves left : "+empOwnDetails.getNoOfLeaves());
						break;
						
					case 4:
						List<Employee> subEmpList = managerService.displaySubEmployees(userName);
						for(Employee subordinate:subEmpList)
						{
							System.out.println("\tEmployee Id : "+subordinate.getUserId()
							+"\n\tName : "+subordinate.getUserName()
							+"\n\tSalary : "+subordinate.getSalary()
							+"\n\tDepartment Id : "+subordinate.getDepartmentId()
							+"\n\tDate of Birth : "+subordinate.getDateOfBirth()
							+"\n\tContact Number : "+subordinate.getContactNumber()
							+"\n\tManager Id : "+subordinate.getManagerId()
							+"\n\tNumber of leaves left : "+subordinate.getNoOfLeaves());
							System.out.println("\n\n");
						}
						break;
						
					case 5:
						List<Leave> leaveList=managerService.showLeavesApplied(userName);
						for(Leave leave:leaveList)
						{
							System.out.println("\n\tEmployee Id : "+leave.getLeaveId()
							+"\n\tLeave Id : "+leave.getEmpId()
							+"\n\tManager Id : "+leave.getManagerId()
							+"\n\tFrom Date : "+leave.getFromDate()
							+"\n\tTo Date : "+leave.getToDate()
							+"\n\tAppled Date : "+leave.getAppliedDate()
							+"\n\tReason for leave : "+leave.getReason());
							if(!leave.isLeaveStatus())
							{
								System.out.println("\tLeave Status : Pending for approval");
							}
						}
						break;
						
					case 6:
						System.out.println("Enter leave id to be accepted");
						int leaveId=scanner.nextInt();
						boolean leaveAcceptStatus=managerService.accept(leaveId);
						if(leaveAcceptStatus)
						{
							System.out.println("Leave accepted sucessfully");
						}
						break;
						
					case 7:
						System.out.println("Enter leave id for rejection");
						int leaveId2=scanner.nextInt();
						System.out.println("Enter reason for rejection");
						String reason=scanner.next();
						boolean rejectStatus=managerService.reject(leaveId2, reason);
						if(rejectStatus)
						{
							System.out.println("Sucessfully rejected");
						}
						break;
						
					case 8:
						System.out.println("Enter old password");
						String oldPassword=scanner.next();
						System.out.println("Enter new password");
						String newPassword=scanner.next();
						boolean pwdChangeStatus=managerService.changeAccountPassword(oldPassword, newPassword,userName);
						if(pwdChangeStatus)
						{
							System.out.println("changed successfully");
						}
						break;
						
					default:
						System.out.println("Exit/Logout");
						
				}
			}while(choice!=7);
			
		}
		else if(valid && loginChoice==3)
		{
			System.out.println("Employee\n1.Search EMployee By Id\n"
					+ "2.Search employee By Name\n"
					+ "3.Display own details\n"
					+ "4.change account password\n"
					+ "5.check attendance\n"
					+ "6.apply for leave\n"
					+ "7.Edit leave\n"
					+ "8.search any leave\n"
					+ "9.cancel any leave");
			int employeeChoice=scanner.nextInt();
			EmployeeDao employeeDto=new EmployeeDaoImpl();
			switch(employeeChoice)
			{
				case 1:
					System.out.println("Enter employee id to be searched");
					int empSearchId=scanner.nextInt();
					Employee searchedEmp=employeeDto.searchEmployeeById(empSearchId);
					System.out.println("The employee details are: "+searchedEmp);
					break;
				case 2:
					System.out.println("Enter Employee name to be searched");
					String empName=scanner.next();
					List<Employee> empTotalList=employeeDto.searchEmployeeByName(empName);
					for(Employee result:empTotalList)
					{
						System.out.println(result);
					}
					break;
				case 3:
					Employee empOwnDetails=employeeDto.displayEmpDetails();
					System.out.println(empOwnDetails);
					break;
				case 4:
					System.out.println("Enter old password");
					String oldPassword=scanner.next();
					System.out.println("Enter new password");
					String newPassword=scanner.next();
					boolean pwdChangeStatus=employeeDto.changeAccountPassword(oldPassword, newPassword);
					if(pwdChangeStatus)
					{
						System.out.println("changed successfully");
					}
					break;
				case 5:
					int attendance=employeeDto.checkAttendance();
					System.out.println("Attendance is: "+attendance);
					break;
				case 6:
					System.out.println("Enter from date in the format yyyy mm dd");
					int fromYear=scanner.nextInt();
					int fromMonth=scanner.nextInt();
					int fromDate=scanner.nextInt();
					LocalDate fDate=LocalDate.of(fromYear, fromMonth, fromDate);
					System.out.println("Enter to date in format yyyy mm dd");
					int toYear=scanner.nextInt();
					int toMonth=scanner.nextInt();
					int toDate=scanner.nextInt();
					LocalDate tDate=LocalDate.of(toYear, toMonth, toMonth);
					LocalDate today=LocalDate.now();
					int empId=0;//write code to get access present employee id;
					String reason;
					System.out.println("Enter reason for leave applied");
					reason = scanner.nextLine();
					Leave leave=new Leave(fDate,tDate,today,false,empId,0,reason);
					boolean leaveStatus=employeeDto.addLeave(leave);
					if(leaveStatus)
					{
						System.out.println("Sucessfully");
					}
					break;
				case 7:
					System.out.println("Enter leave id to modify leave");
					int leaveId=scanner.nextInt();
					System.out.println("Enter from date in the format yyyy mm dd");
					int fromYear1=scanner.nextInt();
					int fromMonth1=scanner.nextInt();
					int fromDate1=scanner.nextInt();
					LocalDate fDate1=LocalDate.of(fromYear1, fromMonth1, fromDate1);
					System.out.println("Enter to date in format yyyy mm dd");
					int toYear1=scanner.nextInt();
					int toMonth1=scanner.nextInt();
					int toDate1=scanner.nextInt();
					LocalDate tDate1=LocalDate.of(toYear1, toMonth1, toMonth1);
					LocalDate today1=LocalDate.now();
					Leave editedLeave=employeeDto.editLeave(leaveId, fDate1, tDate1);
					System.out.println("leave modified to: "+editedLeave);
					break;
					
					
					
			}
		}
		else
		{
			System.out.println("Invalid login credentials");
		}
		
	}

}
