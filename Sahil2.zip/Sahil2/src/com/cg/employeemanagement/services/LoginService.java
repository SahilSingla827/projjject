package com.cg.employeemanagement.services;

public interface LoginService {
	public boolean validate(String userName,String password,int userRole);
}
