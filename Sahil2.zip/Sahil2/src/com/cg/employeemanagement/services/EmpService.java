package com.cg.employeemanagement.services;

import java.time.LocalDate;
import java.util.List;

import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.dto.Leave;

public interface EmpService {
	public Employee searchEmployeeById(int empId);
	public List<Employee> searchEmployeeByName(String fName);
	public Employee displayEmpDetails();
	public boolean changeAccountPassword(String oldPassword,String newPassword);
	public boolean addLeave(Leave leave);
	public Leave editLeave(int leaveId,LocalDate fromDate,LocalDate toDate);
	public Leave SearchLeave(int leaveId);
	public boolean cancelLeave(int leaveId);

}
