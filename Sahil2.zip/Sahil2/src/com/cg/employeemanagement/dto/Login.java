package com.cg.employeemanagement.dto;

public class Login {
	private String userName;
	private String loginType;
	private String password;
	private int empId;
	
	public Login(String userName, String loginType, String password,int empId) {
		super();
		this.userName = userName;
		this.loginType = loginType;
		this.password = password;
		this.empId=empId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getLoginType() {
		return loginType;
	}
	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	
	
	
}
