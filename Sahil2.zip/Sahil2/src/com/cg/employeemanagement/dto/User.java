package com.cg.employeemanagement.dto;

import java.time.LocalDate;

public class User {
	private int userId;
	private String userName;
	private float salary;
	private int departmentId;
	private LocalDate dateOfBirth;
	private Long contactNumber;
	private static int userIdCount=1;
	public User()
	{
		
	}
	public User(String userName, float salary, int departmentId, LocalDate dateOfBirth,
			Long contactNumber) {
		super();
		this.userId = userIdCount;
		this.userName = userName;
		this.salary = salary;
		this.departmentId = departmentId;
		this.dateOfBirth = dateOfBirth;
		this.contactNumber = contactNumber;
		userIdCount++;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public int getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", firstName=" + userName  + ", salary=" + salary
				+ ", departmentId=" + departmentId + ", dateOfBirth=" + dateOfBirth + ", contactNumber=" + contactNumber
				+ "]";
	}
	
	
}
