package com.cg.employeemanagement.dto;

public class LeaveResponse {
	
	private int leaveId;
	private String reason;
	
	public LeaveResponse(int leaveId, String reason) {
		super();
		this.leaveId = leaveId;
		this.reason = reason;
	}
	public int getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	

}
